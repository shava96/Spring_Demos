package com.seed.beans;

//TODO:0	Modification required
abstract public class Product {
	private int id;
	private String name;
	private double price;
	
//	TODO:1	Provide no-argument public constructor
//	TODO:2	Provide getters and setters for all attributes.
	

}
