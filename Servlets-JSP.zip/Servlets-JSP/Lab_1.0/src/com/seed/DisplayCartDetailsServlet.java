package com.seed;

//	TODO:1 Make DisplayCartDetailsServlet as a HttpServlet

public class DisplayCartDetailsServlet {

//	TODO:2 	Provide call-back method (called by web container) for HTTP request made using HTTP GET method
//	TODO:3	This method should read products selected by web-client from bookCatelogue.html and 
//					display them in tabular format as html response to the web client.	
}









